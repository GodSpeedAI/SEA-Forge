# SEA Forge Workbench Design System

A reusable Open Design package for SEA Forge’s governed cognition and execution workbench. The system is dark, compact, evidence-first, keyboard-friendly, and explicit about state, authority, provenance, and lawful next actions.

## Product Overview

SEA Forge is a mission-control application and workbench for governed cognition and execution. Its primary surfaces cover Readiness, Thoth, Assets, Domain Models, Cases, Inbox and Approvals, Operations, Evidence, Memory, Capabilities, Specification Pipelines, Artifacts, Federation, Integrity, and Administration.

Within a case, the workbench supports Overview, Horizon, Timeline, Plan, Command Runs, Agent Tasks, Settlement, and Evidence. The interface keeps approval separate from execution, execution separate from settlement, agent termination separate from settlement, and settlement separate from capability.

## Source Context

The system is derived from the eight substantial SEA Forge design, UX, interaction, mapping, and frontend-contract documents preserved at the project root. `context/source-context.md` records the Open Design handoff; `context-provenance.md` records the evidence inventory and derivation decisions.

## Reuse Workflow

1. Read `DESIGN.md` for the visual and interaction grammar.
2. Import `colors_and_type.css` before product-specific styles.
3. Review `preview/colors-primary.html`, `preview/components-governance.html`, and `preview/applied-readiness.html`.
4. Open `ui_kits/app/index.html` for the applied Readiness Console kit.
5. Read `SKILL.md` before generating a new SEA Forge surface.

When implementing in React/Tauri, replace static review data with typed source-backed view models. Preserve state-domain labels, protected-action results, evidence access, keyboard behavior, and the three depth levels.

## Package Contents

```text
DESIGN.md                     Canonical product and design rules
DESIGN-spec-mapping.md        Semantic traceability to SEA Forge views
colors_and_type.css           Reusable tokens and global type foundations
SKILL.md                      Agent-facing application instructions
context/provenance.md         Evidence inventory and derivation notes
assets/README.md              Source-asset availability and usage boundary
preview/manifest.json         Review-card index
preview/*.html                Focused review cards
ui_kits/app/index.html        Applied Readiness workbench
ui_kits/app/styles.css        Applied layout and component styling
ui_kits/app/components.js     Reusable HTML render functions
ui_kits/app/components/*.html Source-backed semantic component references
ui_kits/app/app.js            Local interactions and state transitions
ui_kits/app/README.md         UI-kit reuse guide
```

The substantial copied SEA Forge specifications remain at the project root as preserved source evidence.

## Preview Manifest

| Review card | Purpose |
|---|---|
| `preview/colors-primary.html` | Surface, text, and semantic state roles |
| `preview/typography-specimens.html` | Semantic type scale and machine values |
| `preview/spacing-tokens.html` | 4px grid and judgment-weighted rows |
| `preview/radius-shadows.html` | Three depth levels and restrained elevation |
| `preview/components-governance.html` | Governed focus, dual state, freshness, and why |
| `preview/components-actions.html` | Enabled, unavailable, and escalated protected actions |
| `preview/brand-assets.html` | Explicit source-asset boundary |
| `preview/applied-readiness.html` | Live load of the applied Readiness UI kit |

The machine-readable index is `preview/manifest.json`.

## Assets, Fonts, and Build Artifacts

No source-approved logo, app icon, tray icon, avatar, wordmark, imagery, runtime icon, or font binary was present. `assets/README.md` preserves that boundary. `build/` and `fonts/` are omitted because there are no evidence-backed files to place in them.

## Core Laws

- One governed focus and one dominant lawful action per screen.
- Always name the state domain; never show generic success.
- Keep execution, settlement, dialogue, termination, integrity, and capability separate.
- Show source, freshness, evidence, and disabled-action reasons within one action.
- Use compact rows, panels, tables, and drawers rather than card grids.
- Treat agent work as bounded operations, not casual chat.

## Runtime

The previews and UI kit are standalone HTML/CSS/JavaScript with no build step and no network dependencies. They are suitable for Open Design preview, static hosting, and extraction into a React/Tauri implementation.
